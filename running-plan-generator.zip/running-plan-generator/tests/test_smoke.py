from running_plan_generator import (
    AthleteConfig,
    Objective,
    generate_plan,
    plan_to_dataframe,
)

def test_generate_plan_smoke():
    config = AthleteConfig(
        name="Atleta Teste",
        objective=Objective.TEN_K,
        initial_weekly_volume_km=40.0,
        frequency_per_week=5,
        max_weekly_volume_km=70.0,
        race_distance_km=10.0,
        race_time_min=40.0,
        has_injury_history=False,
    )
    plan = generate_plan(config, num_weeks=8, feedback_list=None)
    df = plan_to_dataframe(plan)
    assert not df.empty
    assert df["week"].nunique() == 8
