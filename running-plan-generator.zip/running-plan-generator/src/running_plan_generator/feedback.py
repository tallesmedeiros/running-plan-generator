from __future__ import annotations
from typing import List, Dict
from .config import SessionFeedback


def apply_feedback_to_volumes(
    weekly_volumes: List[float],
    feedback_list: List[SessionFeedback],
    max_increment_ratio: float = 0.10,
    min_decrement_ratio: float = 0.10,
) -> List[float]:
    num_weeks = len(weekly_volumes)
    new_volumes = weekly_volumes.copy()

    feedback_by_week: Dict[int, List[SessionFeedback]] = {}
    for fb in feedback_list:
        feedback_by_week.setdefault(fb.week, []).append(fb)

    for t in range(1, num_weeks):
        if t not in feedback_by_week:
            continue

        fbs = feedback_by_week[t]
        if not fbs:
            continue

        comp = sum(1 for fb in fbs if fb.completed) / len(fbs)
        mean_rpe = sum(fb.rpe for fb in fbs) / len(fbs)
        mean_pain = sum(fb.pain for fb in fbs) / len(fbs)

        V_next = new_volumes[t]

        if comp < 0.7 or mean_rpe > 8.0 or mean_pain > 6.0:
            V_new = V_next * (1 - min_decrement_ratio)
        elif comp > 0.9 and 4.0 <= mean_rpe <= 6.0 and mean_pain <= 3.0:
            V_new = V_next * (1 + 0.03)
        else:
            V_new = V_next

        V_prev = new_volumes[t - 1]
        if V_new > V_prev * (1 + max_increment_ratio):
            V_new = V_prev * (1 + max_increment_ratio)

        new_volumes[t] = V_new

    return new_volumes
