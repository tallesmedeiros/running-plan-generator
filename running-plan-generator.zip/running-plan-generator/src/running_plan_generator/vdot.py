from __future__ import annotations
import math


def estimate_vdot_from_race(distance_km: float, time_min: float) -> float:
    if distance_km <= 0 or time_min <= 0:
        raise ValueError("distance_km and time_min must be positive.")

    distance_m = distance_km * 1000.0
    v = distance_m / time_min  # m/min

    vo2 = -4.60 + 0.182258 * v + 0.000104 * (v ** 2)

    frac_vo2max = (
        0.8
        + 0.1894393 * math.exp(-0.012778 * time_min)
        + 0.2989558 * math.exp(-0.1932605 * time_min)
    )

    vdot = vo2 / frac_vo2max
    return vdot


def vvo2max_from_vdot(vdot: float) -> float:
    if vdot <= 0:
        raise ValueError("VDOT must be positive.")

    a = 0.000104
    b = 0.182258
    c = -(vdot + 4.60)

    disc = b * b - 4.0 * a * c
    if disc <= 0:
        raise ValueError("Non-positive discriminant while computing vVO2max.")

    v1 = (-b + (disc ** 0.5)) / (2.0 * a)
    v2 = (-b - (disc ** 0.5)) / (2.0 * a)
    v = max(v1, v2)
    return v
