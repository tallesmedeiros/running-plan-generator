from __future__ import annotations


def kmh_to_min_per_km(v_kmh: float) -> float:
    if v_kmh <= 0:
        return float("inf")
    return 60.0 / v_kmh


def min_per_km_to_kmh(pace_min_per_km: float) -> float:
    if pace_min_per_km <= 0:
        return 0.0
    return 60.0 / pace_min_per_km
