from __future__ import annotations
from typing import Dict, List
import math
import pandas as pd
from .config import TrainingSession

BLOCK_LABELS = ["E", "M", "T", "I", "R"]


def infer_block_weights(main_zone: str) -> Dict[str, float]:
    if not main_zone:
        return {}

    parts = [p.strip().upper() for p in main_zone.split("-") if p.strip()]
    blocks: List[str] = []

    for p in parts:
        if p in BLOCK_LABELS:
            blocks.append(p)

    if not blocks:
        for p in parts:
            if p.startswith("Z") and len(p) >= 2 and p[1:].isdigit():
                z_int = int(p[1:])
                if z_int <= 2:
                    blocks.append("E")
                elif z_int == 3:
                    blocks.append("T")
                elif z_int == 4:
                    blocks.append("I")
                elif z_int >= 5:
                    blocks.append("R")

    if not blocks:
        return {}

    w = 1.0 / len(blocks)
    return {b: w for b in blocks}


def sanity_check_zone_distribution(
    plan: List[TrainingSession],
) -> pd.DataFrame:
    week_stats: Dict[int, Dict[str, float]] = {}

    for sess in plan:
        week = sess.week
        if week not in week_stats:
            week_stats[week] = {
                "total_distance_km": 0.0,
                "total_time_min": 0.0,
                "E_min": 0.0,
                "M_min": 0.0,
                "T_min": 0.0,
                "I_min": 0.0,
                "R_min": 0.0,
            }

        dist = sess.distance_km or 0.0
        week_stats[week]["total_distance_km"] += dist

        if (
            sess.pace_min_per_km_slow is not None
            and sess.pace_min_per_km_fast is not None
            and math.isfinite(sess.pace_min_per_km_slow)
            and math.isfinite(sess.pace_min_per_km_fast)
        ):
            pace_mean = 0.5 * (sess.pace_min_per_km_slow + sess.pace_min_per_km_fast)
        else:
            pace_mean = 6.0

        time_min = dist * pace_mean
        week_stats[week]["total_time_min"] += time_min

        block_weights = infer_block_weights(sess.main_zone)
        if not block_weights:
            continue

        for block, w in block_weights.items():
            key = f"{block}_min"
            if key in week_stats[week]:
                week_stats[week][key] += time_min * w

    rows = []
    for week in sorted(week_stats.keys()):
        stats = week_stats[week]
        row = {
            "week": week,
            "total_distance_km": stats["total_distance_km"],
            "total_time_min": stats["total_time_min"],
            "E_min": stats["E_min"],
            "M_min": stats["M_min"],
            "T_min": stats["T_min"],
            "I_min": stats["I_min"],
            "R_min": stats["R_min"],
        }
        tt = stats["total_time_min"] if stats["total_time_min"] > 0 else 1.0
        row["E_pct"] = 100.0 * stats["E_min"] / tt
        row["M_pct"] = 100.0 * stats["M_min"] / tt
        row["T_pct"] = 100.0 * stats["T_min"] / tt
        row["I_pct"] = 100.0 * stats["I_min"] / tt
        row["R_pct"] = 100.0 * stats["R_min"] / tt

        rows.append(row)

    df = pd.DataFrame(rows)
    df = df.sort_values("week").reset_index(drop=True)

    print("Sanity check: distribuição de tempo por blocos E/M/T/I/R (por semana)")
    print("=" * 72)
    for _, r in df.iterrows():
        w = int(r["week"])
        td = r["total_distance_km"]
        tt = r["total_time_min"]
        print(f"Semana {w:2d} | Dist total: {td:5.1f} km | Tempo total: {tt:6.1f} min")
        print(
            "   E: {:5.1f} min ({:5.1f}%) | "
            "M: {:5.1f} min ({:5.1f}%) | "
            "T: {:5.1f} min ({:5.1f}%)".format(
                r["E_min"], r["E_pct"],
                r["M_min"], r["M_pct"],
                r["T_min"], r["T_pct"],
            )
        )
        print(
            "   I: {:5.1f} min ({:5.1f}%) | "
            "R: {:5.1f} min ({:5.1f}%)".format(
                r["I_min"], r["I_pct"],
                r["R_min"], r["R_pct"],
            )
        )
        print("-" * 72)

    return df
