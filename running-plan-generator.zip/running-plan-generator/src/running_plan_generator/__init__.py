"""Deterministic running training plan generator based on VDOT (Daniels-like)."""

from .config import (
    Objective,
    Phase,
    SessionKind,
    AthleteConfig,
    SessionTemplate,
    TrainingSession,
    SessionFeedback,
)

from .vdot import estimate_vdot_from_race, vvo2max_from_vdot
from .zones import build_daniels_zones_from_vdot, parse_main_zone_range
from .session_library import build_session_library
from .training_plan import generate_plan, plan_to_dataframe
from .feedback import apply_feedback_to_volumes
from .sanity_check import sanity_check_zone_distribution
