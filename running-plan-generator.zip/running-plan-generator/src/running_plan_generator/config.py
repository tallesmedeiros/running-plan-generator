from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional


class Objective(Enum):
    FIVE_K = "5k"
    TEN_K = "10k"
    HALF_MARATHON = "21k"
    MARATHON = "42k"


class Phase(Enum):
    BASE = auto()
    BUILD = auto()
    SPECIFIC = auto()
    TAPER = auto()


class SessionKind(Enum):
    EASY = "EASY"
    LONG = "LONG"
    INTERVAL_SHORT = "INTERVAL_SHORT"
    INTERVAL_LONG = "INTERVAL_LONG"
    TEMPO = "TEMPO"
    RECOVERY = "RECOVERY"


@dataclass
class AthleteConfig:
    name: str
    objective: Objective
    initial_weekly_volume_km: float
    frequency_per_week: int
    max_weekly_volume_km: float
    race_distance_km: float
    race_time_min: float
    has_injury_history: bool = False


@dataclass
class SessionTemplate:
    id: str
    kind: SessionKind
    base_distance_km: float
    main_zone: str
    description: str
    applicable_objectives: List[Objective]
    tags: Optional[List[str]] = None


@dataclass
class TrainingSession:
    week: int
    day_index: int
    phase: Phase
    kind: SessionKind
    distance_km: float
    main_zone: str
    description: str
    template_id: str
    pace_min_per_km_slow: float | None = None
    pace_min_per_km_fast: float | None = None


@dataclass
class SessionFeedback:
    week: int
    day_index: int
    completed: bool
    rpe: float
    pain: float
