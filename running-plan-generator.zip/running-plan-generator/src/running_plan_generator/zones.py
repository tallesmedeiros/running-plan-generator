from __future__ import annotations
from typing import Dict, Tuple, Optional, List
from .vdot import vvo2max_from_vdot
from .utils import kmh_to_min_per_km


def build_daniels_zones_from_vdot(vdot: float) -> Dict[str, Tuple[float, float]]:
    v_vdot_m_per_min = vvo2max_from_vdot(vdot)
    v_vdot_kmh = v_vdot_m_per_min * 60.0 / 1000.0

    main_blocks = {
        "E": (0.59, 0.74),
        "M": (0.75, 0.84),
        "T": (0.83, 0.88),
        "I": (0.95, 1.05),
        "R": (1.05, 1.15),
    }

    zones: Dict[str, Tuple[float, float]] = {}

    for label, (f_low, f_high) in main_blocks.items():
        v_low = f_low * v_vdot_kmh
        v_high = f_high * v_vdot_kmh
        pace_slow = kmh_to_min_per_km(v_low)
        pace_fast = kmh_to_min_per_km(v_high)
        zones[label] = (pace_slow, pace_fast)

    sub_zones = {
        "Z1": (0.59, 0.68),
        "Z2": (0.68, 0.80),
        "Z3": (0.80, 0.88),
        "Z4": (0.88, 1.03),
        "Z5": (1.03, 1.15),
    }

    for label, (f_low, f_high) in sub_zones.items():
        v_low = f_low * v_vdot_kmh
        v_high = f_high * v_vdot_kmh
        pace_slow = kmh_to_min_per_km(v_low)
        pace_fast = kmh_to_min_per_km(v_high)
        zones[label] = (pace_slow, pace_fast)

    return zones


def parse_main_zone_range(
    main_zone: str,
    zones: Dict[str, Tuple[float, float]],
) -> Tuple[Optional[float], Optional[float]]:
    if not main_zone:
        return None, None

    parts: List[str] = [p.strip() for p in main_zone.split("-") if p.strip()]

    if len(parts) == 1:
        z = parts[0]
        if z in zones:
            return zones[z]
        return None, None

    valid = [z for z in parts if z in zones]
    if not valid:
        return None, None

    slow_vals = [zones[z][0] for z in valid]
    fast_vals = [zones[z][1] for z in valid]

    pace_slow = max(slow_vals)
    pace_fast = min(fast_vals)
    return pace_slow, pace_fast
