from __future__ import annotations
from typing import List
from .config import Objective, SessionKind, SessionTemplate


def build_session_library() -> List[SessionTemplate]:
    templates: List[SessionTemplate] = []

    for obj in Objective:
        templates.append(
            SessionTemplate(
                id=f"EASY_{obj.value}_1",
                kind=SessionKind.EASY,
                base_distance_km=8.0,
                main_zone="E",
                description="Rodagem fácil contínua em zona Easy (E).",
                applicable_objectives=[obj],
                tags=["easy"],
            )
        )
        templates.append(
            SessionTemplate(
                id=f"EASY_{obj.value}_2",
                kind=SessionKind.EASY,
                base_distance_km=10.0,
                main_zone="E",
                description="Rodagem confortável, ritmo de conversa, em zona Easy (E).",
                applicable_objectives=[obj],
                tags=["easy"],
            )
        )
        templates.append(
            SessionTemplate(
                id=f"REC_{obj.value}_1",
                kind=SessionKind.RECOVERY,
                base_distance_km=6.0,
                main_zone="E",
                description="Corrida muito leve de recuperação (E bem lento).",
                applicable_objectives=[obj],
                tags=["recovery"],
            )
        )

    templates += [
        SessionTemplate(
            id="LONG_5K_1",
            kind=SessionKind.LONG,
            base_distance_km=12.0,
            main_zone="E-M",
            description="Longão contínuo, começando em Easy (E) e podendo aproximar ritmo de M.",
            applicable_objectives=[Objective.FIVE_K],
            tags=["long"],
        ),
        SessionTemplate(
            id="LONG_10K_1",
            kind=SessionKind.LONG,
            base_distance_km=16.0,
            main_zone="E-M",
            description="Longão contínuo em zona Easy a Marathon (E-M).",
            applicable_objectives=[Objective.TEN_K],
            tags=["long"],
        ),
        SessionTemplate(
            id="LONG_21K_1",
            kind=SessionKind.LONG,
            base_distance_km=22.0,
            main_zone="E-M",
            description="Longão contínuo em zona Easy a Marathon (E-M).",
            applicable_objectives=[Objective.HALF_MARATHON],
            tags=["long"],
        ),
        SessionTemplate(
            id="LONG_42K_1",
            kind=SessionKind.LONG,
            base_distance_km=28.0,
            main_zone="E-M",
            description="Longão contínuo em zona Easy a Marathon (E-M).",
            applicable_objectives=[Objective.MARATHON],
            tags=["long"],
        ),
        SessionTemplate(
            id="LONG_21K_prog",
            kind=SessionKind.LONG,
            base_distance_km=24.0,
            main_zone="M-T",
            description="Longão com parte final progressiva até zona Threshold (M-T).",
            applicable_objectives=[Objective.HALF_MARATHON],
            tags=["long", "progressive"],
        ),
        SessionTemplate(
            id="LONG_42K_prog",
            kind=SessionKind.LONG,
            base_distance_km=30.0,
            main_zone="M",
            description="Longão com últimos 8–10 km em ritmo de maratona (M).",
            applicable_objectives=[Objective.MARATHON],
            tags=["long", "specific"],
        ),
    ]

    templates += [
        SessionTemplate(
            id="INTS_5K_1",
            kind=SessionKind.INTERVAL_SHORT,
            base_distance_km=6.0,
            main_zone="I-R",
            description="8x400 m forte em zona Interval–Repetition (I-R), com 200 m trote.",
            applicable_objectives=[Objective.FIVE_K],
            tags=["VO2max", "short_intervals"],
        ),
        SessionTemplate(
            id="INTS_5K_2",
            kind=SessionKind.INTERVAL_SHORT,
            base_distance_km=7.0,
            main_zone="I-R",
            description="6x600 m em ritmo de prova curta (I-R) com 300 m trote.",
            applicable_objectives=[Objective.FIVE_K],
            tags=["VO2max"],
        ),
        SessionTemplate(
            id="INTS_10K_1",
            kind=SessionKind.INTERVAL_SHORT,
            base_distance_km=7.0,
            main_zone="I",
            description="6x800 m em zona Interval (I) com 400 m trote.",
            applicable_objectives=[Objective.TEN_K],
            tags=["VO2max"],
        ),
        SessionTemplate(
            id="INTS_10K_2",
            kind=SessionKind.INTERVAL_SHORT,
            base_distance_km=8.0,
            main_zone="I",
            description="10x400 m forte em zona Interval (I) com 200 m trote.",
            applicable_objectives=[Objective.TEN_K],
            tags=["VO2max"],
        ),
        SessionTemplate(
            id="INTS_21K_1",
            kind=SessionKind.INTERVAL_SHORT,
            base_distance_km=8.0,
            main_zone="T-I",
            description="6x800 m entre zona Threshold e Interval (T-I) com recuperação moderada.",
            applicable_objectives=[Objective.HALF_MARATHON],
            tags=["threshold", "VO2mix"],
        ),
        SessionTemplate(
            id="INTS_42K_1",
            kind=SessionKind.INTERVAL_SHORT,
            base_distance_km=9.0,
            main_zone="T",
            description="10x500 m em zona Threshold (T) com 300 m trote.",
            applicable_objectives=[Objective.MARATHON],
            tags=["threshold"],
        ),
    ]

    templates += [
        SessionTemplate(
            id="INTL_5K_1",
            kind=SessionKind.INTERVAL_LONG,
            base_distance_km=8.0,
            main_zone="T",
            description="3x1600 m em ritmo de 10 km (Threshold, T) com 3' trote.",
            applicable_objectives=[Objective.FIVE_K, Objective.TEN_K],
            tags=["threshold"],
        ),
        SessionTemplate(
            id="INTL_10K_1",
            kind=SessionKind.INTERVAL_LONG,
            base_distance_km=10.0,
            main_zone="T",
            description="4x2000 m em ritmo de 10–15 km (Threshold, T) com 3' trote.",
            applicable_objectives=[Objective.TEN_K],
            tags=["threshold"],
        ),
        SessionTemplate(
            id="INTL_21K_1",
            kind=SessionKind.INTERVAL_LONG,
            base_distance_km=12.0,
            main_zone="M-T",
            description="3x3000 m entre ritmo de meia e limiar (M-T) com 3' trote.",
            applicable_objectives=[Objective.HALF_MARATHON],
            tags=["specific"],
        ),
        SessionTemplate(
            id="INTL_42K_1",
            kind=SessionKind.INTERVAL_LONG,
            base_distance_km=14.0,
            main_zone="M-T",
            description="3x4000 m entre ritmo de maratona e limiar (M-T).",
            applicable_objectives=[Objective.MARATHON],
            tags=["specific"],
        ),
    ]

    templates += [
        SessionTemplate(
            id="TEMP_5K_1",
            kind=SessionKind.TEMPO,
            base_distance_km=8.0,
            main_zone="T",
            description="20–25' contínuos em ritmo de limiar (T).",
            applicable_objectives=[Objective.FIVE_K, Objective.TEN_K],
            tags=["threshold"],
        ),
        SessionTemplate(
            id="TEMP_10K_1",
            kind=SessionKind.TEMPO,
            base_distance_km=10.0,
            main_zone="T",
            description="30' em ritmo sustentado de limiar (T).",
            applicable_objectives=[Objective.TEN_K],
            tags=["threshold"],
        ),
        SessionTemplate(
            id="TEMP_21K_1",
            kind=SessionKind.TEMPO,
            base_distance_km=12.0,
            main_zone="M-T",
            description="Tempo run contínuo entre ritmo de meia e limiar (M-T).",
            applicable_objectives=[Objective.HALF_MARATHON],
            tags=["specific"],
        ),
        SessionTemplate(
            id="TEMP_42K_1",
            kind=SessionKind.TEMPO,
            base_distance_km=14.0,
            main_zone="M",
            description="Bloco contínuo em ritmo de maratona (M).",
            applicable_objectives=[Objective.MARATHON],
            tags=["specific"],
        ),
    ]

    return templates
