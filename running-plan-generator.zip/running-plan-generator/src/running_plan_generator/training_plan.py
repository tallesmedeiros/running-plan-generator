from __future__ import annotations
from typing import List, Dict, Optional
import math
import random
import pandas as pd

from .config import (
    AthleteConfig,
    Objective,
    Phase,
    SessionKind,
    SessionTemplate,
    TrainingSession,
    SessionFeedback,
)
from .vdot import estimate_vdot_from_race
from .zones import build_daniels_zones_from_vdot, parse_main_zone_range
from .session_library import build_session_library
from .feedback import apply_feedback_to_volumes


def define_phases(num_weeks: int) -> List[Phase]:
    t_base = int(math.floor(0.4 * num_weeks))
    t_build = int(math.floor(0.4 * num_weeks))
    t_spec = int(math.floor(0.15 * num_weeks))
    t_taper = num_weeks - t_base - t_build - t_spec

    phases: List[Phase] = []
    phases += [Phase.BASE] * t_base
    phases += [Phase.BUILD] * t_build
    phases += [Phase.SPECIFIC] * t_spec
    phases += [Phase.TAPER] * t_taper
    return phases[:num_weeks]


def generate_weekly_volumes(
    config: AthleteConfig,
    phases: List[Phase],
    alpha_base: float = 0.05,
    alpha_build: float = 0.03,
    deload_every: int = 4,
    taper_factor: float = 0.8,
    max_increment_ratio: float = 0.10,
) -> List[float]:
    V: List[float] = []
    V_prev = config.initial_weekly_volume_km

    for t, phase in enumerate(phases, start=1):
        if t == 1:
            V_t = V_prev
        else:
            if phase == Phase.BASE:
                V_t = V_prev * (1 + alpha_base)
            elif phase == Phase.BUILD:
                V_t = V_prev * (1 + alpha_build)
            elif phase == Phase.SPECIFIC:
                V_t = V_prev
            elif phase == Phase.TAPER:
                V_t = V_prev * taper_factor
            else:
                V_t = V_prev

        if deload_every > 0 and phase != Phase.TAPER and t % deload_every == 0:
            V_t = V_prev * 0.8

        if abs(V_t - V_prev) > max_increment_ratio * V_prev:
            sign = 1 if (V_t - V_prev) > 0 else -1
            V_t = V_prev * (1 + sign * max_increment_ratio)

        V_t = min(V_t, config.max_weekly_volume_km)

        V.append(V_t)
        V_prev = V_t

    return V


def week_template(
    phase: Phase,
    objective: Objective,
    freq: int,
) -> List[SessionKind]:
    if freq < 3 or freq > 6:
        raise ValueError("Supported weekly frequency: 3–6 sessions.")

    if freq == 3:
        if phase in (Phase.BASE, Phase.BUILD):
            return [
                SessionKind.INTERVAL_SHORT,
                SessionKind.EASY,
                SessionKind.LONG,
            ]
        return [
            SessionKind.TEMPO,
            SessionKind.EASY,
            SessionKind.LONG,
        ]

    if freq == 4:
        if phase == Phase.BASE:
            return [
                SessionKind.EASY,
                SessionKind.INTERVAL_SHORT,
                SessionKind.EASY,
                SessionKind.LONG,
            ]
        if phase == Phase.BUILD:
            return[
                SessionKind.EASY,
                SessionKind.INTERVAL_LONG,
                SessionKind.EASY,
                SessionKind.LONG,
            ]
        return [
            SessionKind.EASY,
            SessionKind.TEMPO,
            SessionKind.EASY,
            SessionKind.LONG,
        ]

    if freq == 5:
        if phase == Phase.BASE:
            return [
                SessionKind.EASY,
                SessionKind.INTERVAL_SHORT,
                SessionKind.EASY,
                SessionKind.EASY,
                SessionKind.LONG,
            ]
        if phase == Phase.BUILD:
            return [
                SessionKind.EASY,
                SessionKind.INTERVAL_SHORT,
                SessionKind.EASY,
                SessionKind.INTERVAL_LONG,
                SessionKind.LONG,
            ]
        return [
            SessionKind.EASY,
            SessionKind.TEMPO,
            SessionKind.EASY,
            SessionKind.INTERVAL_SHORT,
            SessionKind.LONG,
        ]

    if freq == 6:
        if phase == Phase.BASE:
            return [
                SessionKind.EASY,
                SessionKind.INTERVAL_SHORT,
                SessionKind.EASY,
                SessionKind.EASY,
                SessionKind.EASY,
                SessionKind.LONG,
            ]
        if phase == Phase.BUILD:
            return [
                SessionKind.EASY,
                SessionKind.INTERVAL_SHORT,
                SessionKind.EASY,
                SessionKind.INTERVAL_LONG,
                SessionKind.EASY,
                SessionKind.LONG,
            ]
        return [
            SessionKind.EASY,
            SessionKind.TEMPO,
            SessionKind.EASY,
            SessionKind.INTERVAL_SHORT,
            SessionKind.EASY,
            SessionKind.LONG,
        ]

    raise ValueError("Unsupported weekly frequency.")


def session_volume_factors(session_kinds: List[SessionKind]) -> List[float]:
    base_weights = {
        SessionKind.LONG: 3.0,
        SessionKind.INTERVAL_LONG: 1.4,
        SessionKind.INTERVAL_SHORT: 1.2,
        SessionKind.TEMPO: 1.3,
        SessionKind.EASY: 1.0,
        SessionKind.RECOVERY: 0.6,
    }

    w = [base_weights[k] for k in session_kinds]
    total = sum(w)
    return [wi / total for wi in w]


def filter_templates(
    templates: List[SessionTemplate],
    objective: Objective,
    kind: SessionKind,
) -> List[SessionTemplate]:
    return [
        tpl for tpl in templates
        if tpl.kind == kind and objective in tpl.applicable_objectives
    ]


def was_recently_used(
    history: List[TrainingSession],
    candidate_template_id: str,
    current_week: int,
    window_weeks: int = 4,
) -> bool:
    lower_week = max(1, current_week - window_weeks)
    for sess in history:
        if lower_week <= sess.week < current_week:
            if sess.template_id == candidate_template_id:
                return True
    return False


def choose_template_deterministically(
    templates: List[SessionTemplate],
    config: AthleteConfig,
    week: int,
    day_index: int,
    history: List[TrainingSession],
    phase: Phase,
    window_weeks: int = 4,
) -> SessionTemplate:
    if not templates:
        raise ValueError("No templates available for this kind/objective.")

    candidates = [
        tpl for tpl in templates
        if not was_recently_used(history, tpl.id, week, window_weeks)
    ]
    if not candidates:
        candidates = templates

    seed_value = hash((config.name, config.objective.value, week, day_index, phase.name))
    rnd = random.Random(seed_value)

    candidates_sorted = sorted(candidates, key=lambda t: t.id)
    idx = rnd.randint(0, len(candidates_sorted) - 1)
    return candidates_sorted[idx]


def adjust_template_distance(
    template: SessionTemplate,
    target_distance: float,
    max_scale: float = 1.3,
    min_scale: float = 0.7,
) -> float:
    base = template.base_distance_km
    if base <= 0:
        return target_distance

    scale = target_distance / base
    scale = max(min_scale, min(max_scale, scale))
    return round(base * scale, 1)


def generate_plan(
    config: AthleteConfig,
    num_weeks: int,
    feedback_list: Optional[List[SessionFeedback]] = None,
) -> List[TrainingSession]:
    phases = define_phases(num_weeks)
    weekly_volumes = generate_weekly_volumes(config, phases)

    if feedback_list:
        weekly_volumes = apply_feedback_to_volumes(weekly_volumes, feedback_list)

    vdot = estimate_vdot_from_race(config.race_distance_km, config.race_time_min)
    zones = build_daniels_zones_from_vdot(vdot)

    templates_lib = build_session_library()
    plan: List[TrainingSession] = []

    for week_idx in range(num_weeks):
        week = week_idx + 1
        phase = phases[week_idx]
        V_t = weekly_volumes[week_idx]

        kinds = week_template(phase, config.objective, config.frequency_per_week)
        betas = session_volume_factors(kinds)

        for day_idx, kind in enumerate(kinds, start=1):
            v_target = betas[day_idx - 1] * V_t

            candidate_templates = filter_templates(
                templates_lib,
                config.objective,
                kind,
            )

            chosen_tpl = choose_template_deterministically(
                candidate_templates,
                config,
                week,
                day_idx,
                plan,
                phase,
            )

            distance_km = adjust_template_distance(chosen_tpl, v_target)

            pace_slow, pace_fast = parse_main_zone_range(
                chosen_tpl.main_zone,
                zones,
            )

            session = TrainingSession(
                week=week,
                day_index=day_idx,
                phase=phase,
                kind=kind,
                distance_km=distance_km,
                main_zone=chosen_tpl.main_zone,
                description=chosen_tpl.description,
                template_id=chosen_tpl.id,
                pace_min_per_km_slow=pace_slow,
                pace_min_per_km_fast=pace_fast,
            )
            plan.append(session)

    return plan


def plan_to_dataframe(plan: List[TrainingSession]) -> pd.DataFrame:
    records = []
    for sess in plan:
        rec = {
            "week": sess.week,
            "day_index": sess.day_index,
            "phase": sess.phase.name,
            "kind": sess.kind.value,
            "distance_km": sess.distance_km,
            "main_zone": sess.main_zone,
            "template_id": sess.template_id,
            "description": sess.description,
        }
        if sess.pace_min_per_km_slow is not None and sess.pace_min_per_km_fast is not None:
            rec["pace_slow_min_per_km"] = round(sess.pace_min_per_km_slow, 1)
            rec["pace_fast_min_per_km"] = round(sess.pace_min_per_km_fast, 1)
        else:
            rec["pace_slow_min_per_km"] = None
            rec["pace_fast_min_per_km"] = None
        records.append(rec)

    df = pd.DataFrame.from_records(records)
    df = df.sort_values(by=["week", "day_index"]).reset_index(drop=True)
    return df
